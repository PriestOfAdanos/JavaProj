import lib.myFunc;
import lib.randRangeChildren;
import lib.weights;
import lib.firstGeneration;

public class MyClass {
    
    
    public static void main(String args[]) {
    int a = 0;
    int b = 3;
    int m = 50;
    int n = 20;

    Double [] w, ch;
    Double [] a1 = firstGeneration.f1(a,b,n);
    w = weights.weights(a1,n,a,b);
    ch = randRangeChildren.f1(a1,w,n,a,b);
    w = weights.weights(ch,n,a,b);
    
    for(int j = 0;j<m;j++){
    ch = randRangeChildren.f1(ch,weights.weights(ch,n,a,b),n,a,b);
    w = weights.weights(ch,n,a,b);
    }
    System.out.println("Funkcja f(x) osiąga wartość największą równą: ");
    System.out.println(w[0]);
    System.out.println("Dla argumentu x:");
    System.out.println(ch[0]);

}}