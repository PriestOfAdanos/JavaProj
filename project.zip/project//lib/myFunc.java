package lib;



import java.lang.Math ;

public class myFunc {
    public static Double  f1(Double x, int a, int b) {
      if(x>b || x<a){
          return -1.0;
      }
    return x*x;

    }
}