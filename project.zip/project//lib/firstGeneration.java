package lib;

import java.lang.Math;
import java.util.Arrays;  
import java.util.Random;
import java.util.Comparator;

public class firstGeneration {
    public static Double[]  f1(int a, int b, int n) {
        Double children[] = new Double[n];
        Random rand = new Random();
        for(int i=0;i<n;i++){
            Double rd1 = rand.nextDouble();
            children[i]=myFunc.f1((rd1*b)+a,a,b);
        }
        Comparator<Double> sortingByValue = (s1,  s2)-> {return myFunc.f1(s2,a,b).compareTo(myFunc.f1(s1,a,b));};
        Arrays.sort(children, sortingByValue);
        return children;
    }
}