package lib;

import java.lang.Math;
import java.util.Arrays;  
import java.util.Random;
import lib.myFunc;
import java.util.Collection;


public class weights {
    
    public static Double[]  weights(Double [] values, int n, int a, int b) 
    {
        Double [] children = new Double[n];
        Double sum=0.0;
        for(int i=0;i<n;i++){
            sum+=myFunc.f1(values[i],a,b);
            children[i]=sum;

        }
      return children;
    }
}