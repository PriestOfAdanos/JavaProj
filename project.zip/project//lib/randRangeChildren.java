package lib;

import java.lang.Math;
import java.util.Arrays;  
import java.util.Random;
import java.util.Collections;
import java.util.Comparator;
import lib.myFunc;
import lib.firstGeneration;


public class randRangeChildren {
    public static Double[]  f1(Double [] parents, Double [] distr, int n, int a, int b) {
        Double [] children = new Double[n];
        Double [] combined = new Double[2*n];
        Double [] bestOfAll = new Double[n];
        Random rand = new Random();
        for(int i=0;i<n;i++){
            Double rd1 = rand.nextDouble();
            Double rd2 = rand.nextDouble();
            Double tmp1=0.0;
            Double tmp2=0.0;
            
            for(int j=n-1;j>0;j--){
                if(rd1<(distr[j]/distr[n-1])){
                    tmp1=parents[j];
                }
                //if(rd2<(distr[j]/distr[n-1])){
                //    tmp2=parents[j];
                //}
            }
            //children[i]=(tmp1+tmp2)/2
            children[i]=tmp1;
        }
        for(int i=0;i<n-1;i++){
            children[i]=(children[i]+children[i+1])/2;
        }
        System.arraycopy(children, 0, combined, 0, n);
        System.arraycopy(parents, 0, combined, n, n);
        Comparator<Double> sortingByValue = (s1,  s2)-> {return myFunc.f1(s2,a,b).compareTo(myFunc.f1(s1,a,b));};
        Arrays.sort(combined, sortingByValue);
        double d=(double) n;  
        int new_n = (int) Math.round(0.9*d);
        
        
        for(int i=new_n;i<n;i++){
            combined[i]=firstGeneration.f1(a,b,n)[i];
        }
        Arrays.sort(combined, sortingByValue);
        for(int i=0;i<n;i++){bestOfAll[i]=combined[i];}
        return bestOfAll;
    }
}